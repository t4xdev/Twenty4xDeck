/**
 * Twenty4x lead relay: receives the website's demo-request form and emails it through Brevo.
 *
 * Why a relay: the Brevo API key must never be in the website's code, because anyone can read
 * page source. The key lives here as an encrypted Worker secret (BREVO_API_KEY).
 *
 * Environment (wrangler.toml [vars] + one secret):
 *   BREVO_API_KEY     secret   Brevo API v3 key            (wrangler secret put BREVO_API_KEY)
 *   LEAD_RECIPIENTS   var      comma-separated inboxes that receive every enquiry
 *   SENDER_EMAIL      var      a sender verified in Brevo (Senders, domains and dedicated IPs)
 *   SENDER_NAME       var      display name for the sender
 *   ALLOWED_ORIGINS   var      comma-separated site origins allowed to post, e.g. https://twenty4x.com
 *   DB                D1       optional; every lead is saved here (schema.sql)
 *   ADMIN_PASSWORD    secret   password for the lead list at GET /leads and /leads.csv (any username)
 *
 * Request:  POST JSON, the payload built by the website (source 'twenty4x-bridge-lead-form', version 3)
 * Response: 200 {ok:true, messageId} only when Brevo accepted the email; otherwise 4xx/5xx {ok:false, error}
 */
const BREVO_URL = 'https://api.brevo.com/v3/smtp/email';
const MAX_BODY = 20000;
const PERSONAL = /@(gmail|googlemail|yahoo|hotmail|outlook|live|icloud|me|proton|protonmail|aol|rediffmail|ymail)\./i;

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clip = (s, n) => String(s ?? '').trim().slice(0, n);
const list = (v) => String(v || '').split(',').map((x) => x.trim()).filter(Boolean);

function cors(origin, env) {
  const allowed = list(env.ALLOWED_ORIGINS);
  const ok = origin && (allowed.includes(origin) || allowed.includes('*'));
  return ok
    ? { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Max-Age': '86400', Vary: 'Origin' }
    : { Vary: 'Origin' };
}
const json = (status, body, headers) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...headers } });

/* validate and normalise the website payload; never trust it */
export function readLead(p) {
  if (!p || typeof p !== 'object') return { error: 'invalid_payload' };
  if (p.hp) return { spam: true };                                   /* honeypot filled: a bot */
  const c = p.contact || {};
  const lead = {
    name: clip(c.name, 120), email: clip(c.email, 200), company: clip(c.company, 160), role: clip(c.role, 80), note: clip(c.note, 1000),
    size: clip(p.fleet?.size, 20), types: (Array.isArray(p.fleet?.vesselTypes) ? p.fleet.vesselTypes : []).slice(0, 10).map((t) => clip(t, 40)),
    priorities: (Array.isArray(p.priorities) ? p.priorities : []).slice(0, 12).map((x) => ({ priority: clip(x?.priority, 80), modules: (Array.isArray(x?.suggestedModules) ? x.suggestedModules : []).slice(0, 6).map((m) => clip(m, 40)) })),
    modules: (Array.isArray(p.suggestedModules) ? p.suggestedModules : []).slice(0, 10).map((m) => clip(m, 40)),
    attribution: Object.fromEntries(Object.entries(p.attribution || {}).slice(0, 8).map(([k, v]) => [clip(k, 30), clip(v, 300)])),
    seconds: Number.isFinite(p.journey?.secondsToComplete) ? p.journey.secondsToComplete : null,
    submittedAt: clip(p.submittedAt, 40),
  };
  if (!lead.name) return { error: 'name_required' };
  if (!lead.company) return { error: 'company_required' };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(lead.email)) return { error: 'email_invalid' };
  return { lead };
}

export function buildEmail(l) {
  const subject = `New demo request: ${l.company}${l.size ? ` · ${l.size} vessels` : ''}`;
  const row = (k, v) => (v ? `<tr><td style="padding:6px 14px 6px 0;color:#5a6a80;font:600 12px/1.4 Arial;text-transform:uppercase;letter-spacing:.06em;vertical-align:top;white-space:nowrap">${esc(k)}</td><td style="padding:6px 0;color:#0b1d36;font:15px/1.5 Arial">${v}</td></tr>` : '');
  const pri = l.priorities.length ? `<ul style="margin:0;padding-left:18px">${l.priorities.map((x) => `<li>${esc(x.priority)}${x.modules.length ? ` <span style="color:#5a6a80">(suggested: ${esc(x.modules.join(', '))})</span>` : ''}</li>`).join('')}</ul>` : '';
  const attr = Object.entries(l.attribution).map(([k, v]) => `${esc(k)}: ${esc(v)}`).join('<br>');
  const html = `<!doctype html><html><body style="margin:0;background:#eef3f8;padding:24px">
<table role="presentation" style="max-width:620px;margin:0 auto;background:#fff;border-radius:12px;border:1px solid #d6e1ec" cellpadding="0" cellspacing="0"><tr><td style="padding:24px 28px">
<p style="margin:0 0 4px;font:600 12px Arial;letter-spacing:.12em;text-transform:uppercase;color:#11639f">Twenty4x website · demo request</p>
<h1 style="margin:0 0 16px;font:600 22px/1.3 Arial;color:#0b1d36">${esc(l.name)} at ${esc(l.company)}</h1>
<table role="presentation" cellpadding="0" cellspacing="0">
${row('Name', esc(l.name))}${row('Work email', `<a href="mailto:${esc(l.email)}" style="color:#11639f">${esc(l.email)}</a>${PERSONAL.test(l.email) ? ' <span style="color:#9a6412">(personal address)</span>' : ''}`)}
${row('Company', esc(l.company))}${row('Role', esc(l.role))}
${row('Fleet size', l.size ? esc(l.size) + ' vessels' : 'Not given')}${row('Vessel types', esc(l.types.join(', ')))}
${row('Priorities', pri || 'Skipped')}${row('Suggested for demo', esc(l.modules.join(', ')))}
${row('Note', esc(l.note).replace(/\n/g, '<br>'))}
</table>
<p style="margin:18px 0 0;font:12.5px/1.5 Arial;color:#5a6a80">Suggestions are generated from the visitor's answers and are not a confirmed fit. Reply to this email to answer ${esc(l.name.split(' ')[0])} directly.</p>
${attr || l.seconds != null ? `<p style="margin:14px 0 0;font:12px/1.5 Arial;color:#7a8798">${attr}${attr && l.seconds != null ? '<br>' : ''}${l.seconds != null ? `Time to complete: ${esc(l.seconds)} s` : ''}${l.submittedAt ? `<br>Submitted: ${esc(l.submittedAt)}` : ''}</p>` : ''}
</td></tr></table></body></html>`;
  const text = [
    'Twenty4x website: demo request', '',
    `Name: ${l.name}`, `Work email: ${l.email}`, `Company: ${l.company}`, l.role && `Role: ${l.role}`,
    `Fleet size: ${l.size ? l.size + ' vessels' : 'Not given'}`, l.types.length && `Vessel types: ${l.types.join(', ')}`,
    l.priorities.length ? 'Priorities:\n' + l.priorities.map((x) => ` - ${x.priority}`).join('\n') : 'Priorities: skipped',
    l.modules.length && `Suggested for demo: ${l.modules.join(', ')}`, l.note && `\nNote: ${l.note}`,
    '', 'Suggestions are generated from the visitor\'s answers and are not a confirmed fit.',
  ].filter(Boolean).join('\n');
  return { subject, html, text };
}

/* ---------- lead storage (D1). Failures are logged and never block the email. ---------- */
async function saveLead(env, l, origin) {
  if (!env.DB) return null;
  try {
    const r = await env.DB.prepare(
      `INSERT INTO leads (name,email,company,role,note,fleet_size,vessel_types,priorities,modules,attribution,seconds,origin)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
    ).bind(l.name, l.email, l.company, l.role, l.note, l.size, l.types.join(', '),
      l.priorities.map((x) => x.priority).join('; '), l.modules.join(', '),
      JSON.stringify(l.attribution), l.seconds, origin).run();
    return r.meta?.last_row_id ?? null;
  } catch (e) { console.log('db_save_error', String(e)); return null; }
}
async function setStatus(env, id, status) {
  if (!env.DB || id == null) return;
  try { await env.DB.prepare('UPDATE leads SET email_status=? WHERE id=?').bind(status, id).run(); }
  catch (e) { console.log('db_status_error', String(e)); }
}

/* ---------- admin view: browser login prompt, any username + ADMIN_PASSWORD ---------- */
async function same(a, b) {
  const enc = new TextEncoder();
  const [x, y] = await Promise.all([a, b].map((s) => crypto.subtle.digest('SHA-256', enc.encode(s))));
  return crypto.subtle.timingSafeEqual(x, y);
}
async function authorized(request, env) {
  if (!env.ADMIN_PASSWORD) return false;
  const m = /^Basic (.+)$/.exec(request.headers.get('Authorization') || '');
  if (!m) return false;
  let decoded = ''; try { decoded = atob(m[1]); } catch { return false; }
  return same(decoded.slice(decoded.indexOf(':') + 1), env.ADMIN_PASSWORD);
}
const COLS = ['id', 'created_at', 'name', 'email', 'company', 'role', 'fleet_size', 'vessel_types', 'priorities', 'modules', 'note', 'origin', 'email_status', 'attribution'];
const csvCell = (v) => { const s = String(v ?? ''); return /[",\n\r]/.test(s) || /^[=+\-@]/.test(s) ? `"${(/^[=+\-@]/.test(s) ? "'" : '') + s.replace(/"/g, '""')}"` : s; };

async function adminView(request, env, url) {
  if (!(await authorized(request, env))) {
    return new Response(env.ADMIN_PASSWORD ? 'Login required' : 'Set the ADMIN_PASSWORD secret first', {
      status: 401, headers: { 'WWW-Authenticate': 'Basic realm="Twenty4x leads", charset="UTF-8"', 'Cache-Control': 'no-store' },
    });
  }
  if (!env.DB) return new Response('No database bound (DB)', { status: 500 });
  const { results = [] } = await env.DB.prepare(`SELECT ${COLS.join(',')} FROM leads ORDER BY id DESC LIMIT 5000`).all();
  const noStore = { 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex' };

  if (url.pathname === '/leads.csv') {
    const body = [COLS.join(','), ...results.map((r) => COLS.map((c) => csvCell(r[c])).join(','))].join('\r\n');
    return new Response('﻿' + body, { headers: { ...noStore, 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="twenty4x-leads-${new Date().toISOString().slice(0, 10)}.csv"` } });
  }
  const badge = (s) => `<span class="b ${esc(s)}">${esc(s)}</span>`;
  const rows = results.map((r) => `<tr>
<td class="n">${esc(r.id)}</td><td class="t">${esc(r.created_at)} UTC</td>
<td><b>${esc(r.name)}</b><br><a href="mailto:${esc(r.email)}">${esc(r.email)}</a>${PERSONAL.test(r.email || '') ? ' <i>personal</i>' : ''}</td>
<td>${esc(r.company)}<br><small>${esc(r.role)}</small></td>
<td>${esc(r.fleet_size)}<br><small>${esc(r.vessel_types)}</small></td>
<td><small>${esc(r.priorities)}</small></td><td><small>${esc(r.note)}</small></td>
<td>${badge(r.email_status)}<br><small>${esc(r.origin)}</small></td></tr>`).join('');
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><title>Twenty4x leads</title><style>
body{margin:0;font:14px/1.45 system-ui,-apple-system,Segoe UI,Arial;background:#eef3f8;color:#0b1d36}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;padding:20px 16px}
h1{margin:0;font-size:20px}a{color:#11639f}.btn{background:#11639f;color:#fff;padding:8px 14px;border-radius:8px;text-decoration:none;font-weight:600}
.wrap{overflow-x:auto;margin:0 16px 24px;background:#fff;border:1px solid #d6e1ec;border-radius:12px}
table{border-collapse:collapse;width:100%;min-width:900px}th,td{padding:10px 12px;text-align:left;vertical-align:top;border-bottom:1px solid #e6edf4}
th{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#5a6a80;background:#f6f9fc;position:sticky;top:0}
small{color:#5a6a80}i{color:#9a6412;font-style:normal;font-size:12px}.n,.t{white-space:nowrap;color:#5a6a80}
.b{display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;font-weight:600;background:#e6edf4}
.b.sent{background:#dcf3e4;color:#17663a}.b.failed{background:#fde2e1;color:#a32020}.b.pending{background:#fff1d6;color:#8a5a00}
.empty{padding:40px;text-align:center;color:#5a6a80}</style></head><body>
<header><h1>Website leads <small>(${results.length})</small></h1><a class="btn" href="/leads.csv">Download CSV</a></header>
<div class="wrap">${results.length ? `<table><thead><tr><th>#</th><th>Received</th><th>Contact</th><th>Company</th><th>Fleet</th><th>Priorities</th><th>Note</th><th>Email</th></tr></thead><tbody>${rows}</tbody></table>` : '<div class="empty">No leads yet.</div>'}</div>
</body></html>`;
  return new Response(html, { headers: { ...noStore, 'Content-Type': 'text/html; charset=utf-8' } });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'GET' && (url.pathname === '/leads' || url.pathname === '/leads.csv')) return adminView(request, env, url);
    const origin = request.headers.get('Origin') || '';
    const h = cors(origin, env);
    if (request.method === 'OPTIONS') return new Response(null, { status: h['Access-Control-Allow-Origin'] ? 204 : 403, headers: h });
    if (request.method !== 'POST') return json(405, { ok: false, error: 'method_not_allowed' }, h);
    if (!h['Access-Control-Allow-Origin']) return json(403, { ok: false, error: 'origin_not_allowed' }, h);
    if (!env.BREVO_API_KEY || !env.SENDER_EMAIL || !list(env.LEAD_RECIPIENTS).length) return json(500, { ok: false, error: 'relay_not_configured' }, h);

    const raw = await request.text();
    if (raw.length > MAX_BODY) return json(413, { ok: false, error: 'too_large' }, h);
    let p; try { p = JSON.parse(raw); } catch { return json(400, { ok: false, error: 'invalid_json' }, h); }
    const r = readLead(p);
    if (r.spam) return json(200, { ok: true }, h);                 /* look successful to bots, send nothing */
    if (r.error) return json(422, { ok: false, error: r.error }, h);

    const leadId = await saveLead(env, r.lead, origin);
    const { subject, html, text } = buildEmail(r.lead);
    const res = await fetch(BREVO_URL, {
      method: 'POST',
      headers: { 'api-key': env.BREVO_API_KEY, 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        sender: { email: env.SENDER_EMAIL, name: env.SENDER_NAME || 'Twenty4x Website' },
        to: list(env.LEAD_RECIPIENTS).map((email) => ({ email })),
        replyTo: { email: r.lead.email, name: r.lead.name },
        subject, htmlContent: html, textContent: text, tags: ['website-lead'],
      }),
    });
    if (res.status === 201 || res.ok) {
      const b = await res.json().catch(() => ({}));
      await setStatus(env, leadId, 'sent');
      return json(200, { ok: true, messageId: b.messageId || null }, h);
    }
    const detail = await res.text().catch(() => '');
    console.log('brevo_error', res.status, detail.slice(0, 500));       /* visible in `wrangler tail`, never sent to the browser */
    await setStatus(env, leadId, 'failed');
    return json(502, { ok: false, error: 'email_failed' }, h);
  },
};
