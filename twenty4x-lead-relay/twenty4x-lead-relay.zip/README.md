# Twenty4x lead relay (Brevo)

Every "Get a tailored demo" submission on the website is emailed through Brevo to:

- hello@twenty4x.com
- ceo@twenty4x.com
- productmanager@maritimeexpertise.com

Reply-to is set to the visitor, so hitting Reply answers them directly.

## Why this small relay exists

The Brevo API key must never be placed in the website's code: anyone can read page source and
use the key to send email from your Brevo account. The key lives in this Cloudflare Worker as an
encrypted secret. The website only knows the Worker's URL.

## One-time setup (about 10 minutes)

1. **Brevo: verify the sender.** Mail is sent from `noreply@twenty4x.net`. The domain `twenty4x.net`
   is already authenticated in Brevo (Settings, *Senders, domains and dedicated IPs*). To use a
   different address, change `SENDER_EMAIL` in `wrangler.toml`; it must be on an authenticated domain.
2. **Brevo: API key.** Brevo, *SMTP and API*, *API keys*: create a v3 key. Keep it out of chat,
   email and the website code.
3. **Cloudflare: account.** A free Cloudflare account is enough. Install Node.js 18+.
4. **Allowed origins.** In `wrangler.toml`, set `ALLOWED_ORIGINS` to every address the site is served
   from, for example `https://twenty4x.com,https://www.twenty4x.com`. Other websites are refused.
5. **Deploy.** In this folder:

   ```
   npx wrangler login
   npx wrangler secret put BREVO_API_KEY      # paste the Brevo key when prompted
   npx wrangler deploy
   ```

   Wrangler prints the relay URL, for example `https://twenty4x-lead-relay.<account>.workers.dev`.
6. **Connect the site.** In the site's code, set
   `const ENQUIRY_ENDPOINT='https://twenty4x-lead-relay.<account>.workers.dev';`
   (search for `ENQUIRY_ENDPOINT`). Or set `window.TWENTY4X_ENQUIRY_ENDPOINT` before the page script.
7. **Test.**

   ```
   curl -X POST "$RELAY_URL" -H "Origin: https://twenty4x.com" -H "Content-Type: application/json" \
     -d '{"contact":{"name":"Test Lead","email":"test@example.com","company":"Test Co"},"fleet":{"size":"1 to 5","vesselTypes":["Tankers"]}}'
   ```

   Expect `{"ok":true,"messageId":"..."}` and an email in all three inboxes.
   Watch live errors with `npx wrangler tail`.

## Behaviour

| Situation | Relay answer | What the visitor sees |
|---|---|---|
| Brevo accepted the email | 200 `{ok:true}` | "Request sent" |
| Missing name, company or valid email | 422 | Form error, nothing sent |
| Request from another website | 403 | Nothing sent |
| Bot filled the hidden trap field | 200, nothing sent | (bots only) |
| Brevo error (bad key, unverified sender) | 502 | "Your request was not sent", with email and copy fallback |
| Key or sender not configured | 500 | Same fallback |
| `ENQUIRY_ENDPOINT` empty on the site | (no call) | "Not sent yet", with email and copy fallback |

The website never shows "Request sent" unless the relay confirms Brevo accepted the email.

## Changing recipients

Edit `LEAD_RECIPIENTS` in `wrangler.toml` (comma-separated) and run `npx wrangler deploy`.

## Optional hardening

- Add a Cloudflare rate-limiting rule on the Worker route (for example 5 requests per minute per IP).
- Add Cloudflare Turnstile to the form if spam gets past the hidden trap field.

## Lead list (no email needed)

Every valid submission is saved in the Cloudflare D1 database `twenty4x-leads` (table `leads`, see
`schema.sql`) **before** the email is sent, so leads are kept even if Brevo fails. The `Email`
column shows `sent`, `failed` or `pending`.

- View: open `<relay-url>/leads`. The browser asks for a login: any username, password = `ADMIN_PASSWORD`.
- Download: `<relay-url>/leads.csv` (opens in Excel / Google Sheets).
- Set or change the password: `npx wrangler secret put ADMIN_PASSWORD`
- Query directly: `npx wrangler d1 execute twenty4x-leads --remote --command "SELECT * FROM leads ORDER BY id DESC LIMIT 20"`
