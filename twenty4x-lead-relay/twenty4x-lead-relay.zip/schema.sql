CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  name TEXT, email TEXT, company TEXT, role TEXT, note TEXT,
  fleet_size TEXT, vessel_types TEXT, priorities TEXT, modules TEXT,
  attribution TEXT, seconds INTEGER, origin TEXT,
  email_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS leads_created ON leads (created_at DESC);
